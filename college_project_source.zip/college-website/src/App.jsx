import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { useState } from 'react'
import './App.css'

// Components
import Header from './components/Header'
import Footer from './components/Footer'
import HomePage from './components/HomePage'
import StudentPortal from './components/StudentPortal'
import TeacherPortal from './components/TeacherPortal'
import Faculty from './components/Faculty'
import Library from './components/Library'
import Departments from './components/Departments'
import TopStudents from './components/TopStudents'
import Contact from './components/Contact'
import AdminPanel from './components/AdminPanel'

function App() {
  const [user, setUser] = useState(null)

  return (
    <Router>
      <div className="min-h-screen bg-gray-50" dir="rtl">
        <Header user={user} setUser={setUser} />
        <main className="min-h-screen">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/student" element={<StudentPortal user={user} setUser={setUser} />} />
            <Route path="/teacher" element={<TeacherPortal user={user} setUser={setUser} />} />
            <Route path="/faculty" element={<Faculty />} />
            <Route path="/library" element={<Library />} />
            <Route path="/departments" element={<Departments />} />
            <Route path="/top-students" element={<TopStudents />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/admin" element={<AdminPanel user={user} setUser={setUser} />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  )
}

export default App

