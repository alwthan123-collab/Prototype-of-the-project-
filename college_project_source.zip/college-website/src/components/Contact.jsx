import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Phone, Mail, MapPin, Clock, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react'

const Contact = () => {
  const contactInfo = [
    {
      icon: Phone,
      title: 'الهاتف',
      details: ['+964 770 123 4567', '+964 771 234 5678'],
      color: 'text-blue-600'
    },
    {
      icon: Mail,
      title: 'البريد الإلكتروني',
      details: ['info@college.edu', 'admissions@college.edu'],
      color: 'text-green-600'
    },
    {
      icon: MapPin,
      title: 'العنوان',
      details: ['شارع الجامعة، منطقة الكرادة', 'بغداد، العراق'],
      color: 'text-red-600'
    },
    {
      icon: Clock,
      title: 'ساعات العمل',
      details: ['الأحد - الخميس: 8:00 - 16:00', 'الجمعة: 8:00 - 12:00'],
      color: 'text-purple-600'
    }
  ]

  const departments = [
    { name: 'القبول والتسجيل', phone: '+964 770 111 2222', email: 'admissions@college.edu' },
    { name: 'الشؤون الأكاديمية', phone: '+964 770 333 4444', email: 'academic@college.edu' },
    { name: 'شؤون الطلاب', phone: '+964 770 555 6666', email: 'students@college.edu' },
    { name: 'المالية', phone: '+964 770 777 8888', email: 'finance@college.edu' }
  ]

  const socialLinks = [
    { name: 'Facebook', icon: Facebook, href: '#', color: 'text-blue-600' },
    { name: 'Twitter', icon: Twitter, href: '#', color: 'text-sky-500' },
    { name: 'Instagram', icon: Instagram, href: '#', color: 'text-pink-600' },
    { name: 'LinkedIn', icon: Linkedin, href: '#', color: 'text-blue-700' }
  ]

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">تواصل معنا</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            نحن هنا لمساعدتك. تواصل معنا في أي وقت وسنكون سعداء للإجابة على استفساراتك
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Contact Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>إرسال رسالة</CardTitle>
                <CardDescription>
                  املأ النموذج أدناه وسنتواصل معك في أقرب وقت ممكن
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName">الاسم الأول</Label>
                    <Input id="firstName" placeholder="أدخل اسمك الأول" className="mt-1" />
                  </div>
                  <div>
                    <Label htmlFor="lastName">الاسم الأخير</Label>
                    <Input id="lastName" placeholder="أدخل اسمك الأخير" className="mt-1" />
                  </div>
                </div>
                <div>
                  <Label htmlFor="email">البريد الإلكتروني</Label>
                  <Input id="email" type="email" placeholder="أدخل بريدك الإلكتروني" className="mt-1" />
                </div>
                <div>
                  <Label htmlFor="phone">رقم الهاتف</Label>
                  <Input id="phone" type="tel" placeholder="أدخل رقم هاتفك" className="mt-1" />
                </div>
                <div>
                  <Label htmlFor="subject">الموضوع</Label>
                  <select id="subject" className="w-full mt-1 p-2 border rounded-md">
                    <option value="">اختر الموضوع</option>
                    <option value="admission">القبول والتسجيل</option>
                    <option value="academic">الشؤون الأكاديمية</option>
                    <option value="student">شؤون الطلاب</option>
                    <option value="finance">الشؤون المالية</option>
                    <option value="other">أخرى</option>
                  </select>
                </div>
                <div>
                  <Label htmlFor="message">الرسالة</Label>
                  <Textarea
                    id="message"
                    placeholder="اكتب رسالتك هنا..."
                    rows={5}
                    className="mt-1"
                  />
                </div>
                <Button className="w-full">
                  <Mail className="w-4 h-4 ml-2" />
                  إرسال الرسالة
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Contact Information */}
          <div className="space-y-6">
            {/* Contact Details */}
            <Card>
              <CardHeader>
                <CardTitle>معلومات التواصل</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {contactInfo.map((info, index) => {
                  const Icon = info.icon
                  return (
                    <div key={index} className="flex items-start space-x-3 space-x-reverse">
                      <div className={`p-2 rounded-lg bg-gray-100 ${info.color}`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">{info.title}</h4>
                        {info.details.map((detail, idx) => (
                          <p key={idx} className="text-sm text-gray-600">{detail}</p>
                        ))}
                      </div>
                    </div>
                  )
                })}
              </CardContent>
            </Card>

            {/* Departments */}
            <Card>
              <CardHeader>
                <CardTitle>الأقسام الإدارية</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {departments.map((dept, index) => (
                  <div key={index} className="border-b border-gray-200 pb-3 last:border-b-0">
                    <h4 className="font-medium text-gray-900 mb-1">{dept.name}</h4>
                    <div className="text-sm text-gray-600 space-y-1">
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <Phone className="w-4 h-4" />
                        <span>{dept.phone}</span>
                      </div>
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <Mail className="w-4 h-4" />
                        <span>{dept.email}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Social Media */}
            <Card>
              <CardHeader>
                <CardTitle>تابعنا على</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-3">
                  {socialLinks.map((social) => {
                    const Icon = social.icon
                    return (
                      <a
                        key={social.name}
                        href={social.href}
                        className={`flex items-center space-x-2 space-x-reverse p-3 border rounded-lg hover:bg-gray-50 transition-colors ${social.color}`}
                      >
                        <Icon className="w-5 h-5" />
                        <span className="text-sm font-medium">{social.name}</span>
                      </a>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Map Section */}
        <div className="mt-12">
          <Card>
            <CardHeader>
              <CardTitle>موقعنا على الخريطة</CardTitle>
              <CardDescription>
                تجدنا في قلب بغداد في منطقة الكرادة
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="aspect-video bg-gray-200 rounded-lg flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <MapPin className="w-12 h-12 mx-auto mb-2" />
                  <p>خريطة تفاعلية للموقع</p>
                  <p className="text-sm">شارع الجامعة، منطقة الكرادة، بغداد</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

export default Contact

