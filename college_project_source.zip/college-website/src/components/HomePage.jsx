import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { 
  GraduationCap, 
  Users, 
  BookOpen, 
  Building, 
  Trophy, 
  Phone,
  ArrowLeft,
  Star,
  Calendar,
  MapPin,
  Mail
} from 'lucide-react'

const HomePage = () => {
  const quickActions = [
    {
      title: 'مساحة الطالب',
      description: 'الوصول إلى الدرجات والجداول والمواد الدراسية',
      icon: GraduationCap,
      href: '/student',
      color: 'bg-blue-500'
    },
    {
      title: 'الكادر التعليمي',
      description: 'تصفح معلومات أعضاء هيئة التدريس',
      icon: Users,
      href: '/faculty',
      color: 'bg-green-500'
    },
    {
      title: 'المكتبة الرقمية',
      description: 'الوصول إلى الكتب والمراجع والملازم',
      icon: BookOpen,
      href: '/library',
      color: 'bg-purple-500'
    },
    {
      title: 'استكشف الأقسام',
      description: 'تعرف على الأقسام والتخصصات المتاحة',
      icon: Building,
      href: '/departments',
      color: 'bg-orange-500'
    }
  ]

  const news = [
    {
      id: 1,
      title: 'بدء التسجيل للفصل الدراسي الجديد',
      summary: 'يسر إدارة الكلية أن تعلن عن بدء التسجيل للفصل الدراسي الجديد للعام الأكاديمي 2024-2025',
      date: '2024-08-15',
      image: '/api/placeholder/300/200'
    },
    {
      id: 2,
      title: 'ورشة عمل حول التكنولوجيا الحديثة',
      summary: 'تنظم الكلية ورشة عمل متخصصة حول أحدث التطورات في مجال التكنولوجيا والذكاء الاصطناعي',
      date: '2024-08-10',
      image: '/api/placeholder/300/200'
    },
    {
      id: 3,
      title: 'تكريم الطلاب المتفوقين',
      summary: 'حفل تكريم الطلاب المتفوقين في الفصل الدراسي الماضي وتوزيع الجوائز والشهادات التقديرية',
      date: '2024-08-05',
      image: '/api/placeholder/300/200'
    }
  ]

  const stats = [
    { label: 'طالب مسجل', value: '2,500+', icon: GraduationCap },
    { label: 'عضو هيئة تدريس', value: '150+', icon: Users },
    { label: 'قسم أكاديمي', value: '12', icon: Building },
    { label: 'سنة من التميز', value: '25+', icon: Star }
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-6xl font-bold mb-6">
                أهلاً بكم في الكلية الذكية
              </h1>
              <p className="text-xl mb-8 text-blue-100">
                نحن نقدم تعليماً متميزاً يجمع بين الأصالة والحداثة، ونسعى لإعداد جيل قادر على مواجهة تحديات المستقبل
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/student">
                  <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
                    دخول الطلاب
                    <ArrowLeft className="w-5 h-5 mr-2" />
                  </Button>
                </Link>
                <Link to="/departments">
                  <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
                    استكشف الأقسام
                  </Button>
                </Link>
              </div>
            </div>
            <div className="hidden lg:block">
              <img 
                src="/api/placeholder/600/400" 
                alt="مبنى الكلية" 
                className="rounded-lg shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => {
              const Icon = stat.icon
              return (
                <div key={index} className="text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
                    <Icon className="w-8 h-8 text-blue-600" />
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</div>
                  <div className="text-gray-600">{stat.label}</div>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Quick Actions */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">الخدمات الرئيسية</h2>
            <p className="text-lg text-gray-600">الوصول السريع إلى جميع الخدمات التعليمية والإدارية</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {quickActions.map((action, index) => {
              const Icon = action.icon
              return (
                <Link key={index} to={action.href}>
                  <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer group">
                    <CardHeader className="text-center">
                      <div className={`inline-flex items-center justify-center w-16 h-16 ${action.color} rounded-full mb-4 group-hover:scale-110 transition-transform`}>
                        <Icon className="w-8 h-8 text-white" />
                      </div>
                      <CardTitle className="text-xl">{action.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-center">
                        {action.description}
                      </CardDescription>
                    </CardContent>
                  </Card>
                </Link>
              )
            })}
          </div>
        </div>
      </section>

      {/* News Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-12">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">آخر الأخبار</h2>
              <p className="text-lg text-gray-600">تابع أحدث الأخبار والفعاليات في الكلية</p>
            </div>
            <Button variant="outline">
              عرض جميع الأخبار
              <ArrowLeft className="w-4 h-4 mr-2" />
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {news.map((item) => (
              <Card key={item.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="aspect-video bg-gray-200 relative">
                  <img 
                    src={item.image} 
                    alt={item.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 right-4 bg-blue-600 text-white px-3 py-1 rounded-full text-sm">
                    <Calendar className="w-4 h-4 inline ml-1" />
                    {new Date(item.date).toLocaleDateString('ar-SA')}
                  </div>
                </div>
                <CardHeader>
                  <CardTitle className="text-lg">{item.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>{item.summary}</CardDescription>
                  <Button variant="link" className="p-0 mt-4">
                    اقرأ المزيد
                    <ArrowLeft className="w-4 h-4 mr-2" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">هل لديك استفسار؟</h2>
          <p className="text-xl mb-8 text-blue-100">
            فريقنا جاهز للإجابة على جميع استفساراتكم ومساعدتكم في أي وقت
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/contact">
              <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
                <Phone className="w-5 h-5 ml-2" />
                تواصل معنا
              </Button>
            </Link>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
              <Mail className="w-5 h-5 ml-2" />
              info@college.edu
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}

export default HomePage

