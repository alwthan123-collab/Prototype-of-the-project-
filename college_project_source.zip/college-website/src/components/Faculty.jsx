import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Mail, Phone, Clock, MapPin, Search } from 'lucide-react'
import { useState } from 'react'

const Faculty = () => {
  const [searchTerm, setSearchTerm] = useState('')

  const faculty = [
    {
      id: 1,
      name: 'د. أحمد محمد علي',
      position: 'أستاذ',
      department: 'علوم الحاسوب',
      specialization: 'الذكاء الاصطناعي',
      email: 'ahmed.ali@college.edu',
      phone: '+964 770 123 4567',
      office: 'مكتب 301',
      officeHours: 'الأحد - الثلاثاء: 10:00 - 12:00',
      image: '/api/placeholder/150/150'
    },
    {
      id: 2,
      name: 'د. فاطمة أحمد',
      position: 'أستاذ مساعد',
      department: 'الرياضيات',
      specialization: 'الإحصاء التطبيقي',
      email: 'fatima.ahmed@college.edu',
      phone: '+964 770 234 5678',
      office: 'مكتب 205',
      officeHours: 'الاثنين - الأربعاء: 9:00 - 11:00',
      image: '/api/placeholder/150/150'
    },
    {
      id: 3,
      name: 'د. محمد حسن',
      position: 'أستاذ مشارك',
      department: 'الهندسة',
      specialization: 'هندسة البرمجيات',
      email: 'mohammed.hassan@college.edu',
      phone: '+964 770 345 6789',
      office: 'مكتب 102',
      officeHours: 'الأحد - الثلاثاء: 14:00 - 16:00',
      image: '/api/placeholder/150/150'
    },
    {
      id: 4,
      name: 'د. سارة علي',
      position: 'أستاذ',
      department: 'إدارة الأعمال',
      specialization: 'التسويق الرقمي',
      email: 'sara.ali@college.edu',
      phone: '+964 770 456 7890',
      office: 'مكتب 401',
      officeHours: 'الثلاثاء - الخميس: 11:00 - 13:00',
      image: '/api/placeholder/150/150'
    }
  ]

  const filteredFaculty = faculty.filter(member =>
    member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.specialization.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">أعضاء هيئة التدريس</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            تعرف على أعضاء هيئة التدريس المتميزين في كليتنا وخبراتهم الأكاديمية والمهنية
          </p>
        </div>

        {/* Search */}
        <div className="mb-8">
          <div className="relative max-w-md mx-auto">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="البحث عن عضو هيئة تدريس..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pr-10"
            />
          </div>
        </div>

        {/* Faculty Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredFaculty.map((member) => (
            <Card key={member.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <CardHeader className="text-center pb-4">
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
                />
                <CardTitle className="text-xl">{member.name}</CardTitle>
                <CardDescription className="text-blue-600 font-medium">
                  {member.position}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">معلومات أكاديمية</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <MapPin className="w-4 h-4 text-gray-400" />
                      <span>{member.department}</span>
                    </div>
                    <div>
                      <span className="text-gray-600">التخصص: </span>
                      <span>{member.specialization}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium text-gray-900 mb-2">معلومات التواصل</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <Mail className="w-4 h-4 text-gray-400" />
                      <a href={`mailto:${member.email}`} className="text-blue-600 hover:underline">
                        {member.email}
                      </a>
                    </div>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <Phone className="w-4 h-4 text-gray-400" />
                      <span>{member.phone}</span>
                    </div>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <MapPin className="w-4 h-4 text-gray-400" />
                      <span>{member.office}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium text-gray-900 mb-2">الساعات المكتبية</h4>
                  <div className="flex items-center space-x-2 space-x-reverse text-sm">
                    <Clock className="w-4 h-4 text-gray-400" />
                    <span>{member.officeHours}</span>
                  </div>
                </div>

                <Button variant="outline" className="w-full">
                  <Mail className="w-4 h-4 ml-2" />
                  إرسال رسالة
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredFaculty.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500">لم يتم العثور على أعضاء هيئة تدريس مطابقين للبحث</p>
          </div>
        )}
      </div>
    </div>
  )
}

export default Faculty

