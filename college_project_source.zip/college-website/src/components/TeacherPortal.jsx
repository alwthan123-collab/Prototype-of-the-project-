import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { UserCheck, Upload, Users, Calendar, FileText } from 'lucide-react'

const TeacherPortal = ({ user, setUser }) => {
  const [loginData, setLoginData] = useState({ teacherId: '', password: '' })
  const [isLoading, setIsLoading] = useState(false)

  const handleLogin = async (e) => {
    e.preventDefault()
    setIsLoading(true)
    
    setTimeout(() => {
      if (loginData.teacherId === 'T001' && loginData.password === 'teacher123') {
        setUser({ 
          id: 'T001', 
          name: 'د. أحمد محمد علي', 
          department: 'علوم الحاسوب',
          role: 'teacher' 
        })
      } else {
        alert('معرف المعلم أو كلمة المرور غير صحيحة')
      }
      setIsLoading(false)
    }, 1000)
  }

  if (!user || user.role !== 'teacher') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full space-y-8">
          <div className="text-center">
            <UserCheck className="mx-auto h-12 w-12 text-green-600" />
            <h2 className="mt-6 text-3xl font-bold text-gray-900">
              بوابة المعلم
            </h2>
            <p className="mt-2 text-sm text-gray-600">
              أدخل معرف المعلم وكلمة المرور للوصول إلى لوحة التحكم
            </p>
          </div>
          <Card>
            <CardContent className="p-6">
              <form onSubmit={handleLogin} className="space-y-6">
                <div>
                  <Label htmlFor="teacherId">معرف المعلم</Label>
                  <Input
                    id="teacherId"
                    type="text"
                    required
                    value={loginData.teacherId}
                    onChange={(e) => setLoginData({ ...loginData, teacherId: e.target.value })}
                    placeholder="أدخل معرف المعلم"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="password">كلمة المرور</Label>
                  <Input
                    id="password"
                    type="password"
                    required
                    value={loginData.password}
                    onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                    placeholder="أدخل كلمة المرور"
                    className="mt-1"
                  />
                </div>
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? 'جاري تسجيل الدخول...' : 'تسجيل الدخول'}
                </Button>
              </form>
              <div className="mt-4 text-center">
                <p className="text-sm text-gray-600">
                  للتجربة: معرف المعلم: T001، كلمة المرور: teacher123
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">مرحباً، {user.name}</h1>
          <p className="text-gray-600">لوحة تحكم المعلم - {user.department}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">الطلاب المسجلين</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">85</div>
              <p className="text-xs text-muted-foreground">في جميع المقررات</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">المقررات</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">3</div>
              <p className="text-xs text-muted-foreground">مقررات نشطة</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">المحاضرات</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12</div>
              <p className="text-xs text-muted-foreground">هذا الأسبوع</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">المواد المرفوعة</CardTitle>
              <Upload className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">24</div>
              <p className="text-xs text-muted-foreground">ملف ومادة</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>رفع مواد جديدة</CardTitle>
              <CardDescription>إضافة كتب أو ملازم أو مواد تعليمية</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="course">المقرر</Label>
                <select className="w-full mt-1 p-2 border rounded-md">
                  <option>اختر المقرر</option>
                  <option>البرمجة المتقدمة</option>
                  <option>قواعد البيانات</option>
                  <option>الذكاء الاصطناعي</option>
                </select>
              </div>
              <div>
                <Label htmlFor="title">عنوان المادة</Label>
                <Input id="title" placeholder="أدخل عنوان المادة" className="mt-1" />
              </div>
              <div>
                <Label htmlFor="file">الملف</Label>
                <Input id="file" type="file" className="mt-1" />
              </div>
              <Button className="w-full">
                <Upload className="w-4 h-4 ml-2" />
                رفع المادة
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>إدارة الجدول</CardTitle>
              <CardDescription>تحديث مواعيد المحاضرات والساعات المكتبية</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <h4 className="font-medium">المحاضرات القادمة</h4>
                <div className="space-y-2">
                  <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                    <span>البرمجة المتقدمة</span>
                    <span className="text-sm text-gray-600">الأحد 8:00</span>
                  </div>
                  <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                    <span>قواعد البيانات</span>
                    <span className="text-sm text-gray-600">الاثنين 10:00</span>
                  </div>
                </div>
              </div>
              <Button variant="outline" className="w-full">
                <Calendar className="w-4 h-4 ml-2" />
                تحديث الجدول
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

export default TeacherPortal

