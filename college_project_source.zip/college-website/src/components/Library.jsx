import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { BookOpen, Download, Search, Filter } from 'lucide-react'

const Library = () => {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('all')

  const categories = [
    { id: 'all', name: 'جميع الفئات' },
    { id: 'books', name: 'كتب' },
    { id: 'handouts', name: 'ملازم' },
    { id: 'summaries', name: 'ملخصات' },
    { id: 'journals', name: 'مجلات' }
  ]

  const materials = [
    {
      id: 1,
      title: 'مقدمة في البرمجة',
      author: 'د. أحمد محمد',
      category: 'books',
      department: 'علوم الحاسوب',
      size: '2.5 MB',
      type: 'PDF',
      downloads: 245,
      image: '/api/placeholder/120/160'
    },
    {
      id: 2,
      title: 'ملزمة الرياضيات المتقدمة',
      author: 'د. فاطمة أحمد',
      category: 'handouts',
      department: 'الرياضيات',
      size: '1.8 MB',
      type: 'PDF',
      downloads: 189,
      image: '/api/placeholder/120/160'
    },
    {
      id: 3,
      title: 'ملخص قواعد البيانات',
      author: 'د. محمد حسن',
      category: 'summaries',
      department: 'علوم الحاسوب',
      size: '800 KB',
      type: 'PDF',
      downloads: 156,
      image: '/api/placeholder/120/160'
    },
    {
      id: 4,
      title: 'مجلة التكنولوجيا الحديثة',
      author: 'هيئة التحرير',
      category: 'journals',
      department: 'عام',
      size: '5.2 MB',
      type: 'PDF',
      downloads: 98,
      image: '/api/placeholder/120/160'
    }
  ]

  const filteredMaterials = materials.filter(material => {
    const matchesSearch = material.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         material.author.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === 'all' || material.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">المكتبة الرقمية</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            الوصول إلى مجموعة شاملة من الكتب والملازم والمراجع الأكاديمية
          </p>
        </div>

        {/* Search and Filter */}
        <div className="mb-8 space-y-4">
          <div className="relative max-w-md mx-auto">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="البحث في المكتبة..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pr-10"
            />
          </div>
          
          <div className="flex flex-wrap justify-center gap-2">
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category.id)}
              >
                {category.name}
              </Button>
            ))}
          </div>
        </div>

        {/* Materials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredMaterials.map((material) => (
            <Card key={material.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="aspect-[3/4] bg-gray-200 relative">
                <img
                  src={material.image}
                  alt={material.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-2 right-2 bg-blue-600 text-white px-2 py-1 rounded text-xs">
                  {material.type}
                </div>
              </div>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg line-clamp-2">{material.title}</CardTitle>
                <CardDescription>{material.author}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="text-sm text-gray-600 space-y-1">
                  <div>القسم: {material.department}</div>
                  <div>الحجم: {material.size}</div>
                  <div>التحميلات: {material.downloads}</div>
                </div>
                <Button className="w-full" size="sm">
                  <Download className="w-4 h-4 ml-2" />
                  تحميل
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredMaterials.length === 0 && (
          <div className="text-center py-12">
            <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">لم يتم العثور على مواد مطابقة للبحث</p>
          </div>
        )}
      </div>
    </div>
  )
}

export default Library

