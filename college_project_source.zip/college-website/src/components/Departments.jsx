import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Building, Users, DollarSign, Clock } from 'lucide-react'

const Departments = () => {
  const departments = [
    {
      id: 1,
      name: 'علوم الحاسوب',
      description: 'قسم متخصص في تقنيات الحاسوب والبرمجة والذكاء الاصطناعي',
      minGrade: 85,
      tuitionFee: 2500000,
      duration: 4,
      students: 450,
      courses: ['البرمجة', 'قواعد البيانات', 'الذكاء الاصطناعي', 'الشبكات'],
      image: '/api/placeholder/300/200'
    },
    {
      id: 2,
      name: 'الهندسة',
      description: 'قسم الهندسة يشمل تخصصات متنوعة في الهندسة المدنية والكهربائية',
      minGrade: 88,
      tuitionFee: 3000000,
      duration: 5,
      students: 320,
      courses: ['الرياضيات الهندسية', 'الفيزياء', 'التصميم', 'المواد'],
      image: '/api/placeholder/300/200'
    },
    {
      id: 3,
      name: 'إدارة الأعمال',
      description: 'قسم متخصص في إدارة الأعمال والتسويق والمحاسبة',
      minGrade: 80,
      tuitionFee: 2000000,
      duration: 4,
      students: 380,
      courses: ['المحاسبة', 'التسويق', 'الإدارة', 'الاقتصاد'],
      image: '/api/placeholder/300/200'
    },
    {
      id: 4,
      name: 'الطب',
      description: 'كلية الطب تقدم تعليماً طبياً متميزاً وتدريباً عملياً شاملاً',
      minGrade: 95,
      tuitionFee: 5000000,
      duration: 6,
      students: 200,
      courses: ['التشريح', 'الفسيولوجيا', 'الباثولوجيا', 'الطب الباطني'],
      image: '/api/placeholder/300/200'
    }
  ]

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">استكشف الأقسام</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            تعرف على الأقسام الأكاديمية المتاحة ومتطلبات القبول والرسوم الدراسية
          </p>
        </div>

        {/* Departments Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {departments.map((dept) => (
            <Card key={dept.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="aspect-video bg-gray-200">
                <img
                  src={dept.image}
                  alt={dept.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <CardHeader>
                <CardTitle className="text-2xl">{dept.name}</CardTitle>
                <CardDescription className="text-base">{dept.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Stats */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <Users className="w-5 h-5 text-blue-600" />
                    <div>
                      <div className="font-semibold">{dept.students}</div>
                      <div className="text-sm text-gray-600">طالب</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <Clock className="w-5 h-5 text-green-600" />
                    <div>
                      <div className="font-semibold">{dept.duration} سنوات</div>
                      <div className="text-sm text-gray-600">مدة الدراسة</div>
                    </div>
                  </div>
                </div>

                {/* Requirements */}
                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-900">متطلبات القبول</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-blue-50 p-3 rounded-lg">
                      <div className="text-sm text-gray-600">المعدل المطلوب</div>
                      <div className="text-lg font-bold text-blue-600">{dept.minGrade}%</div>
                    </div>
                    <div className="bg-green-50 p-3 rounded-lg">
                      <div className="text-sm text-gray-600">الرسوم السنوية</div>
                      <div className="text-lg font-bold text-green-600">
                        {dept.tuitionFee.toLocaleString()} د.ع
                      </div>
                    </div>
                  </div>
                </div>

                {/* Courses */}
                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-900">المقررات الأساسية</h4>
                  <div className="flex flex-wrap gap-2">
                    {dept.courses.map((course, index) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm"
                      >
                        {course}
                      </span>
                    ))}
                  </div>
                </div>

                <Button className="w-full">
                  <Building className="w-4 h-4 ml-2" />
                  المزيد من التفاصيل
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}

export default Departments

