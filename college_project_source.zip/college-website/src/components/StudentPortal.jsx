import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  User, 
  GraduationCap, 
  Calendar, 
  BookOpen, 
  FileText, 
  Download,
  Clock,
  Award,
  Eye,
  EyeOff
} from 'lucide-react'

const StudentPortal = ({ user, setUser }) => {
  const [loginData, setLoginData] = useState({ studentId: '', password: '' })
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  // Mock student data
  const studentData = {
    id: '2105246',
    name: 'أحمد علي محمد',
    department: 'علوم الحاسوب',
    level: 'الثالث',
    semester: 'الأول',
    gpa: 3.85,
    profileImage: '/api/placeholder/150/150'
  }

  const grades = [
    { course: 'الرياضيات', grade: 95, credits: 3, status: 'مكتمل' },
    { course: 'البرمجة', grade: 88, credits: 4, status: 'مكتمل' },
    { course: 'قواعد البيانات', grade: 92, credits: 3, status: 'مكتمل' },
    { course: 'الشبكات', grade: 85, credits: 3, status: 'جاري' },
    { course: 'الذكاء الاصطناعي', grade: 90, credits: 4, status: 'جاري' }
  ]

  const schedule = [
    { day: 'الأحد', time: '8:00 - 10:00', course: 'الرياضيات', room: 'قاعة 101', type: 'محاضرة' },
    { day: 'الأحد', time: '10:30 - 12:30', course: 'البرمجة', room: 'مختبر 1', type: 'عملي' },
    { day: 'الاثنين', time: '8:00 - 10:00', course: 'قواعد البيانات', room: 'قاعة 205', type: 'محاضرة' },
    { day: 'الثلاثاء', time: '10:00 - 12:00', course: 'الشبكات', room: 'مختبر 2', type: 'عملي' },
    { day: 'الأربعاء', time: '8:00 - 10:00', course: 'الذكاء الاصطناعي', room: 'قاعة 301', type: 'محاضرة' }
  ]

  const materials = [
    { name: 'كتاب الرياضيات - الوحدة الأولى', type: 'PDF', size: '2.5 MB', course: 'الرياضيات' },
    { name: 'ملزمة البرمجة - الفصل الثالث', type: 'PDF', size: '1.8 MB', course: 'البرمجة' },
    { name: 'شرائح قواعد البيانات', type: 'PPT', size: '3.2 MB', course: 'قواعد البيانات' },
    { name: 'أمثلة عملية - الشبكات', type: 'ZIP', size: '5.1 MB', course: 'الشبكات' }
  ]

  const exams = [
    { course: 'الذكاء الاصطناعي', type: 'امتحان نهائي', date: '2024-12-15', time: '09:00', room: 'قاعة 301' },
    { course: 'الشبكات', type: 'امتحان نصفي', date: '2024-11-20', time: '10:00', room: 'قاعة 205' },
    { course: 'البرمجة', type: 'اختبار عملي', date: '2024-11-25', time: '14:00', room: 'مختبر 1' }
  ]

  const handleLogin = async (e) => {
    e.preventDefault()
    setIsLoading(true)
    
    // Simulate API call
    setTimeout(() => {
      if (loginData.studentId === '2105246' && loginData.password === 'password') {
        setUser({ ...studentData, role: 'student' })
      } else {
        alert('رقم الطالب أو كلمة المرور غير صحيحة')
      }
      setIsLoading(false)
    }, 1000)
  }

  if (!user || user.role !== 'student') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full space-y-8">
          <div className="text-center">
            <GraduationCap className="mx-auto h-12 w-12 text-blue-600" />
            <h2 className="mt-6 text-3xl font-bold text-gray-900">
              تسجيل دخول الطالب
            </h2>
            <p className="mt-2 text-sm text-gray-600">
              أدخل رقم الطالب وكلمة المرور للوصول إلى حسابك
            </p>
          </div>
          <Card>
            <CardContent className="p-6">
              <form onSubmit={handleLogin} className="space-y-6">
                <div>
                  <Label htmlFor="studentId">رقم الطالب</Label>
                  <Input
                    id="studentId"
                    type="text"
                    required
                    value={loginData.studentId}
                    onChange={(e) => setLoginData({ ...loginData, studentId: e.target.value })}
                    placeholder="أدخل رقم الطالب"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="password">كلمة المرور</Label>
                  <div className="relative mt-1">
                    <Input
                      id="password"
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={loginData.password}
                      onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                      placeholder="أدخل كلمة المرور"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute left-0 top-0 h-full px-3"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
                <Button
                  type="submit"
                  className="w-full"
                  disabled={isLoading}
                >
                  {isLoading ? 'جاري تسجيل الدخول...' : 'تسجيل الدخول'}
                </Button>
              </form>
              <div className="mt-4 text-center">
                <p className="text-sm text-gray-600">
                  للتجربة: رقم الطالب: 2105246، كلمة المرور: password
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Student Profile Header */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="flex items-center space-x-6 space-x-reverse">
              <img
                src={user.profileImage}
                alt={user.name}
                className="w-20 h-20 rounded-full object-cover"
              />
              <div className="flex-1">
                <h1 className="text-2xl font-bold text-gray-900">{user.name}</h1>
                <p className="text-gray-600">رقم الطالب: {user.id}</p>
                <div className="flex items-center space-x-4 space-x-reverse mt-2">
                  <span className="text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded">
                    {user.department}
                  </span>
                  <span className="text-sm bg-green-100 text-green-800 px-2 py-1 rounded">
                    المستوى {user.level}
                  </span>
                  <span className="text-sm bg-purple-100 text-purple-800 px-2 py-1 rounded">
                    الفصل {user.semester}
                  </span>
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600">{user.gpa}</div>
                <div className="text-sm text-gray-600">المعدل التراكمي</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Main Content */}
        <Tabs defaultValue="grades" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="grades" className="flex items-center space-x-2 space-x-reverse">
              <Award className="w-4 h-4" />
              <span>الدرجات</span>
            </TabsTrigger>
            <TabsTrigger value="schedule" className="flex items-center space-x-2 space-x-reverse">
              <Calendar className="w-4 h-4" />
              <span>الجدول</span>
            </TabsTrigger>
            <TabsTrigger value="materials" className="flex items-center space-x-2 space-x-reverse">
              <BookOpen className="w-4 h-4" />
              <span>المواد</span>
            </TabsTrigger>
            <TabsTrigger value="exams" className="flex items-center space-x-2 space-x-reverse">
              <Clock className="w-4 h-4" />
              <span>الامتحانات</span>
            </TabsTrigger>
          </TabsList>

          {/* Grades Tab */}
          <TabsContent value="grades">
            <Card>
              <CardHeader>
                <CardTitle>الدرجات الأكاديمية</CardTitle>
                <CardDescription>عرض درجاتك في جميع المقررات</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-right py-3 px-4">المقرر</th>
                        <th className="text-right py-3 px-4">الدرجة</th>
                        <th className="text-right py-3 px-4">الساعات</th>
                        <th className="text-right py-3 px-4">الحالة</th>
                      </tr>
                    </thead>
                    <tbody>
                      {grades.map((grade, index) => (
                        <tr key={index} className="border-b hover:bg-gray-50">
                          <td className="py-3 px-4 font-medium">{grade.course}</td>
                          <td className="py-3 px-4">
                            <span className={`font-bold ${grade.grade >= 90 ? 'text-green-600' : grade.grade >= 80 ? 'text-blue-600' : 'text-orange-600'}`}>
                              {grade.grade}
                            </span>
                          </td>
                          <td className="py-3 px-4">{grade.credits}</td>
                          <td className="py-3 px-4">
                            <span className={`px-2 py-1 rounded text-sm ${grade.status === 'مكتمل' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}`}>
                              {grade.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Schedule Tab */}
          <TabsContent value="schedule">
            <Card>
              <CardHeader>
                <CardTitle>الجدول الدراسي</CardTitle>
                <CardDescription>جدولك الأسبوعي للمحاضرات والعملي</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  {schedule.map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                      <div className="flex items-center space-x-4 space-x-reverse">
                        <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                          <Calendar className="w-6 h-6 text-blue-600" />
                        </div>
                        <div>
                          <h3 className="font-medium">{item.course}</h3>
                          <p className="text-sm text-gray-600">{item.day} - {item.time}</p>
                        </div>
                      </div>
                      <div className="text-left">
                        <p className="text-sm font-medium">{item.room}</p>
                        <p className="text-sm text-gray-600">{item.type}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Materials Tab */}
          <TabsContent value="materials">
            <Card>
              <CardHeader>
                <CardTitle>المواد الدراسية</CardTitle>
                <CardDescription>تحميل الكتب والملازم والمراجع</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  {materials.map((material, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                      <div className="flex items-center space-x-4 space-x-reverse">
                        <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                          <FileText className="w-6 h-6 text-green-600" />
                        </div>
                        <div>
                          <h3 className="font-medium">{material.name}</h3>
                          <p className="text-sm text-gray-600">{material.course} • {material.type} • {material.size}</p>
                        </div>
                      </div>
                      <Button size="sm" variant="outline">
                        <Download className="w-4 h-4 ml-2" />
                        تحميل
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Exams Tab */}
          <TabsContent value="exams">
            <Card>
              <CardHeader>
                <CardTitle>مواعيد الامتحانات</CardTitle>
                <CardDescription>الامتحانات القادمة والمواعيد المهمة</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  {exams.map((exam, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                      <div className="flex items-center space-x-4 space-x-reverse">
                        <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                          <Clock className="w-6 h-6 text-red-600" />
                        </div>
                        <div>
                          <h3 className="font-medium">{exam.course}</h3>
                          <p className="text-sm text-gray-600">{exam.type}</p>
                        </div>
                      </div>
                      <div className="text-left">
                        <p className="text-sm font-medium">{exam.date}</p>
                        <p className="text-sm text-gray-600">{exam.time} - {exam.room}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default StudentPortal

