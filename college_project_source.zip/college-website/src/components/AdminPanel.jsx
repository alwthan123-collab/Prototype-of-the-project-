import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Shield, Users, BookOpen, Settings, BarChart3 } from 'lucide-react'

const AdminPanel = ({ user, setUser }) => {
  const [loginData, setLoginData] = useState({ adminId: '', password: '' })
  const [isLoading, setIsLoading] = useState(false)

  const handleLogin = async (e) => {
    e.preventDefault()
    setIsLoading(true)
    
    setTimeout(() => {
      if (loginData.adminId === 'admin' && loginData.password === 'admin123') {
        setUser({ 
          id: 'admin', 
          name: 'مدير النظام', 
          role: 'admin' 
        })
      } else {
        alert('معرف المدير أو كلمة المرور غير صحيحة')
      }
      setIsLoading(false)
    }, 1000)
  }

  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full space-y-8">
          <div className="text-center">
            <Shield className="mx-auto h-12 w-12 text-red-600" />
            <h2 className="mt-6 text-3xl font-bold text-gray-900">
              لوحة الإدارة
            </h2>
            <p className="mt-2 text-sm text-gray-600">
              أدخل معرف المدير وكلمة المرور للوصول إلى لوحة التحكم
            </p>
          </div>
          <Card>
            <CardContent className="p-6">
              <form onSubmit={handleLogin} className="space-y-6">
                <div>
                  <Label htmlFor="adminId">معرف المدير</Label>
                  <Input
                    id="adminId"
                    type="text"
                    required
                    value={loginData.adminId}
                    onChange={(e) => setLoginData({ ...loginData, adminId: e.target.value })}
                    placeholder="أدخل معرف المدير"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="password">كلمة المرور</Label>
                  <Input
                    id="password"
                    type="password"
                    required
                    value={loginData.password}
                    onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                    placeholder="أدخل كلمة المرور"
                    className="mt-1"
                  />
                </div>
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? 'جاري تسجيل الدخول...' : 'تسجيل الدخول'}
                </Button>
              </form>
              <div className="mt-4 text-center">
                <p className="text-sm text-gray-600">
                  للتجربة: معرف المدير: admin، كلمة المرور: admin123
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  const stats = [
    { title: 'إجمالي الطلاب', value: '2,547', icon: Users, color: 'text-blue-600' },
    { title: 'أعضاء هيئة التدريس', value: '156', icon: Users, color: 'text-green-600' },
    { title: 'المقررات النشطة', value: '89', icon: BookOpen, color: 'text-purple-600' },
    { title: 'الأقسام', value: '12', icon: Settings, color: 'text-orange-600' }
  ]

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">مرحباً، {user.name}</h1>
          <p className="text-gray-600">لوحة تحكم الإدارة - نظام إدارة الكلية</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon
            return (
              <Card key={index}>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                  <Icon className={`h-4 w-4 ${stat.color}`} />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stat.value}</div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Management Sections */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* User Management */}
          <Card>
            <CardHeader>
              <CardTitle>إدارة المستخدمين</CardTitle>
              <CardDescription>إضافة وتعديل وحذف المستخدمين</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <h4 className="font-medium">إضافة مستخدم جديد</h4>
                <div className="grid grid-cols-2 gap-2">
                  <Button variant="outline" size="sm">إضافة طالب</Button>
                  <Button variant="outline" size="sm">إضافة معلم</Button>
                </div>
              </div>
              <div className="space-y-2">
                <h4 className="font-medium">إدارة الحسابات</h4>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start">
                    <Users className="w-4 h-4 ml-2" />
                    عرض جميع المستخدمين
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Settings className="w-4 h-4 ml-2" />
                    إدارة الصلاحيات
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Content Management */}
          <Card>
            <CardHeader>
              <CardTitle>إدارة المحتوى</CardTitle>
              <CardDescription>إدارة الأخبار والإعلانات والمواد</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <h4 className="font-medium">المحتوى</h4>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start">
                    <BookOpen className="w-4 h-4 ml-2" />
                    إدارة الأخبار
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <BookOpen className="w-4 h-4 ml-2" />
                    إدارة المكتبة
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <h4 className="font-medium">الإعدادات</h4>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start">
                    <Settings className="w-4 h-4 ml-2" />
                    إعدادات النظام
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <BarChart3 className="w-4 h-4 ml-2" />
                    التقارير والإحصائيات
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recent Activities */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>النشاطات الأخيرة</CardTitle>
              <CardDescription>آخر العمليات التي تمت في النظام</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center space-x-4 space-x-reverse p-3 bg-gray-50 rounded-lg">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">تم إضافة طالب جديد</p>
                    <p className="text-xs text-gray-600">أحمد محمد علي - قسم علوم الحاسوب</p>
                  </div>
                  <span className="text-xs text-gray-500">منذ 5 دقائق</span>
                </div>
                <div className="flex items-center space-x-4 space-x-reverse p-3 bg-gray-50 rounded-lg">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">تم نشر خبر جديد</p>
                    <p className="text-xs text-gray-600">بدء التسجيل للفصل الدراسي الجديد</p>
                  </div>
                  <span className="text-xs text-gray-500">منذ ساعة</span>
                </div>
                <div className="flex items-center space-x-4 space-x-reverse p-3 bg-gray-50 rounded-lg">
                  <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">تم رفع مادة جديدة</p>
                    <p className="text-xs text-gray-600">كتاب البرمجة المتقدمة - د. أحمد علي</p>
                  </div>
                  <span className="text-xs text-gray-500">منذ 3 ساعات</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

export default AdminPanel

