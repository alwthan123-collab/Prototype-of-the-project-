import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Trophy, Medal, Award, Star } from 'lucide-react'

const TopStudents = () => {
  const topStudents = [
    {
      id: 1,
      name: 'سارة أحمد محمد',
      department: 'علوم الحاسوب',
      level: 'الرابع',
      gpa: 3.95,
      rank: 1,
      year: '2023-2024',
      image: '/api/placeholder/150/150',
      achievements: ['أفضل مشروع تخرج', 'منحة التفوق الأكاديمي']
    },
    {
      id: 2,
      name: 'محمد علي حسن',
      department: 'الهندسة',
      level: 'الثالث',
      gpa: 3.92,
      rank: 2,
      year: '2023-2024',
      image: '/api/placeholder/150/150',
      achievements: ['جائزة الابتكار', 'المشاركة في المؤتمر الدولي']
    },
    {
      id: 3,
      name: 'فاطمة خالد أحمد',
      department: 'إدارة الأعمال',
      level: 'الثاني',
      gpa: 3.90,
      rank: 3,
      year: '2023-2024',
      image: '/api/placeholder/150/150',
      achievements: ['جائزة القيادة الطلابية', 'أفضل بحث أكاديمي']
    },
    {
      id: 4,
      name: 'أحمد محمود علي',
      department: 'الطب',
      level: 'الخامس',
      gpa: 3.88,
      rank: 4,
      year: '2023-2024',
      image: '/api/placeholder/150/150',
      achievements: ['جائزة التميز الطبي', 'أفضل تدريب سريري']
    },
    {
      id: 5,
      name: 'نور الهدى حسين',
      department: 'علوم الحاسوب',
      level: 'الثالث',
      gpa: 3.85,
      rank: 5,
      year: '2023-2024',
      image: '/api/placeholder/150/150',
      achievements: ['جائزة البرمجة', 'مشروع التطبيق المتميز']
    },
    {
      id: 6,
      name: 'عبدالله صالح',
      department: 'الهندسة',
      level: 'الرابع',
      gpa: 3.83,
      rank: 6,
      year: '2023-2024',
      image: '/api/placeholder/150/150',
      achievements: ['جائزة التصميم الهندسي', 'براءة اختراع']
    }
  ]

  const getRankIcon = (rank) => {
    switch (rank) {
      case 1:
        return <Trophy className="w-8 h-8 text-yellow-500" />
      case 2:
        return <Medal className="w-8 h-8 text-gray-400" />
      case 3:
        return <Award className="w-8 h-8 text-amber-600" />
      default:
        return <Star className="w-8 h-8 text-blue-500" />
    }
  }

  const getRankColor = (rank) => {
    switch (rank) {
      case 1:
        return 'bg-gradient-to-r from-yellow-400 to-yellow-600'
      case 2:
        return 'bg-gradient-to-r from-gray-300 to-gray-500'
      case 3:
        return 'bg-gradient-to-r from-amber-400 to-amber-600'
      default:
        return 'bg-gradient-to-r from-blue-400 to-blue-600'
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">أوائل السنة</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            نفتخر بطلابنا المتفوقين الذين حققوا إنجازات أكاديمية متميزة
          </p>
          <div className="mt-6 inline-flex items-center space-x-2 space-x-reverse bg-blue-100 text-blue-800 px-4 py-2 rounded-full">
            <Trophy className="w-5 h-5" />
            <span className="font-medium">العام الأكاديمي 2023-2024</span>
          </div>
        </div>

        {/* Top 3 Students - Special Layout */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-center mb-8">المراكز الثلاثة الأولى</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {topStudents.slice(0, 3).map((student, index) => (
              <Card key={student.id} className={`relative overflow-hidden ${index === 0 ? 'md:order-2 transform md:scale-110' : index === 1 ? 'md:order-1' : 'md:order-3'}`}>
                <div className={`absolute top-0 left-0 right-0 h-2 ${getRankColor(student.rank)}`}></div>
                <CardHeader className="text-center pb-4">
                  <div className="relative">
                    <img
                      src={student.image}
                      alt={student.name}
                      className="w-24 h-24 rounded-full mx-auto mb-4 object-cover border-4 border-white shadow-lg"
                    />
                    <div className="absolute -top-2 -right-2 bg-white rounded-full p-2 shadow-lg">
                      {getRankIcon(student.rank)}
                    </div>
                  </div>
                  <CardTitle className="text-xl">{student.name}</CardTitle>
                  <CardDescription>
                    <div className="space-y-1">
                      <div>{student.department}</div>
                      <div className="text-blue-600 font-medium">المستوى {student.level}</div>
                    </div>
                  </CardDescription>
                </CardHeader>
                <CardContent className="text-center space-y-4">
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="text-3xl font-bold text-blue-600">{student.gpa}</div>
                    <div className="text-sm text-gray-600">المعدل التراكمي</div>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">الإنجازات</h4>
                    <div className="space-y-1">
                      {student.achievements.map((achievement, idx) => (
                        <div key={idx} className="text-sm bg-blue-50 text-blue-700 px-2 py-1 rounded">
                          {achievement}
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Other Top Students */}
        <div>
          <h2 className="text-2xl font-bold text-center mb-8">الطلاب المتفوقون</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {topStudents.slice(3).map((student) => (
              <Card key={student.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="text-center pb-4">
                  <div className="relative">
                    <img
                      src={student.image}
                      alt={student.name}
                      className="w-20 h-20 rounded-full mx-auto mb-4 object-cover"
                    />
                    <div className="absolute -top-1 -right-1 bg-blue-600 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold">
                      {student.rank}
                    </div>
                  </div>
                  <CardTitle className="text-lg">{student.name}</CardTitle>
                  <CardDescription>
                    <div className="space-y-1">
                      <div>{student.department}</div>
                      <div className="text-blue-600 font-medium">المستوى {student.level}</div>
                    </div>
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">{student.gpa}</div>
                    <div className="text-sm text-gray-600">المعدل التراكمي</div>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2 text-sm">الإنجازات</h4>
                    <div className="space-y-1">
                      {student.achievements.map((achievement, idx) => (
                        <div key={idx} className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded">
                          {achievement}
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Call to Action */}
        <div className="mt-16 text-center bg-blue-600 text-white rounded-lg p-8">
          <h3 className="text-2xl font-bold mb-4">هل تريد أن تكون من المتفوقين؟</h3>
          <p className="text-blue-100 mb-6">
            انضم إلى كليتنا واحصل على تعليم متميز يؤهلك لتحقيق أحلامك الأكاديمية والمهنية
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-blue-600 px-6 py-3 rounded-lg font-medium hover:bg-gray-100 transition-colors">
              تقدم للقبول
            </button>
            <button className="border border-white text-white px-6 py-3 rounded-lg font-medium hover:bg-white hover:text-blue-600 transition-colors">
              تعرف على المنح
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default TopStudents

