from flask import Blueprint, jsonify, request
from flask_cors import cross_origin

college_bp = Blueprint('college', __name__)

# بيانات تجريبية للطلاب
students_data = {
    "2105246": {
        "id": "2105246",
        "name": "أحمد علي محمد",
        "department": "علوم الحاسوب",
        "level": "الثالث",
        "gpa": 3.85,
        "grades": [
            {"subject": "الرياضيات", "grade": 95, "credits": 3, "status": "مكتمل"},
            {"subject": "البرمجة", "grade": 88, "credits": 4, "status": "مكتمل"},
            {"subject": "قواعد البيانات", "grade": 92, "credits": 3, "status": "مكتمل"},
            {"subject": "الشبكات", "grade": 85, "credits": 3, "status": "جاري"},
            {"subject": "الذكاء الاصطناعي", "grade": 90, "credits": 4, "status": "جاري"}
        ],
        "schedule": [
            {"subject": "الرياضيات", "time": "الأحد - 8:00 - 10:00", "room": "قاعة 101", "type": "محاضرة"},
            {"subject": "البرمجة", "time": "الأحد - 10:30 - 12:30", "room": "معمل 1", "type": "عملي"},
            {"subject": "قواعد البيانات", "time": "الاثنين - 8:00 - 10:00", "room": "قاعة 205", "type": "محاضرة"},
            {"subject": "الشبكات", "time": "الثلاثاء - 10:00 - 12:00", "room": "معمل 2", "type": "عملي"},
            {"subject": "الذكاء الاصطناعي", "time": "الأربعاء - 8:00 - 10:00", "room": "قاعة 301", "type": "محاضرة"}
        ]
    }
}

# بيانات تجريبية للمعلمين
teachers_data = {
    "T001": {
        "id": "T001",
        "name": "د. أحمد محمد علي",
        "department": "علوم الحاسوب",
        "specialization": "الذكاء الاصطناعي",
        "courses": ["البرمجة المتقدمة", "قواعد البيانات", "الذكاء الاصطناعي"],
        "students_count": 85,
        "office": "مكتب 301",
        "office_hours": "الأحد - الثلاثاء: 10:00 - 12:00"
    }
}

# بيانات المكتبة
library_data = [
    {
        "id": 1,
        "title": "مقدمة في البرمجة",
        "author": "د. أحمد محمد",
        "category": "books",
        "department": "علوم الحاسوب",
        "size": "2.5 MB",
        "type": "PDF",
        "downloads": 245
    },
    {
        "id": 2,
        "title": "ملزمة الرياضيات المتقدمة",
        "author": "د. فاطمة أحمد",
        "category": "handouts",
        "department": "الرياضيات",
        "size": "1.8 MB",
        "type": "PDF",
        "downloads": 189
    }
]

@college_bp.route('/student/login', methods=['POST'])
@cross_origin()
def student_login():
    data = request.get_json()
    student_id = data.get('studentId')
    password = data.get('password')
    
    if student_id in students_data and password == 'password':
        return jsonify({
            "success": True,
            "student": students_data[student_id]
        })
    else:
        return jsonify({
            "success": False,
            "message": "رقم الطالب أو كلمة المرور غير صحيحة"
        }), 401

@college_bp.route('/teacher/login', methods=['POST'])
@cross_origin()
def teacher_login():
    data = request.get_json()
    teacher_id = data.get('teacherId')
    password = data.get('password')
    
    if teacher_id in teachers_data and password == 'teacher123':
        return jsonify({
            "success": True,
            "teacher": teachers_data[teacher_id]
        })
    else:
        return jsonify({
            "success": False,
            "message": "معرف المعلم أو كلمة المرور غير صحيحة"
        }), 401

@college_bp.route('/library/materials', methods=['GET'])
@cross_origin()
def get_library_materials():
    category = request.args.get('category', 'all')
    search = request.args.get('search', '')
    
    filtered_materials = library_data
    
    if category != 'all':
        filtered_materials = [m for m in filtered_materials if m['category'] == category]
    
    if search:
        filtered_materials = [m for m in filtered_materials if search.lower() in m['title'].lower() or search.lower() in m['author'].lower()]
    
    return jsonify({
        "success": True,
        "materials": filtered_materials
    })

@college_bp.route('/departments', methods=['GET'])
@cross_origin()
def get_departments():
    departments = [
        {
            "id": 1,
            "name": "علوم الحاسوب",
            "description": "قسم متخصص في تقنيات الحاسوب والبرمجة والذكاء الاصطناعي",
            "minGrade": 85,
            "tuitionFee": 2500000,
            "duration": 4,
            "students": 450
        },
        {
            "id": 2,
            "name": "الهندسة",
            "description": "قسم الهندسة يشمل تخصصات متنوعة في الهندسة المدنية والكهربائية",
            "minGrade": 88,
            "tuitionFee": 3000000,
            "duration": 5,
            "students": 320
        }
    ]
    
    return jsonify({
        "success": True,
        "departments": departments
    })

@college_bp.route('/news', methods=['GET'])
@cross_origin()
def get_news():
    news = [
        {
            "id": 1,
            "title": "بدء التسجيل للفصل الدراسي الجديد",
            "content": "يسر إدارة الكلية أن تعلن عن بدء التسجيل للفصل الدراسي الجديد للعام الأكاديمي 2024-2025",
            "date": "2024-02-11",
            "category": "إعلانات"
        },
        {
            "id": 2,
            "title": "ورشة عمل حول التكنولوجيا الحديثة",
            "content": "تنظم الكلية ورشة عمل متخصصة حول أحدث التطورات في مجال التكنولوجيا والذكاء الاصطناعي",
            "date": "2024-02-06",
            "category": "فعاليات"
        }
    ]
    
    return jsonify({
        "success": True,
        "news": news
    })

