# تصميم قاعدة البيانات - Firestore

## هيكل المجموعات (Collections) والوثائق (Documents)

### 1. مجموعة المستخدمين (users)
```
users/
├── {userId}/
    ├── uid: string
    ├── email: string
    ├── role: string (student, teacher, admin)
    ├── name: string
    ├── profileImage: string (URL)
    ├── createdAt: timestamp
    ├── lastLogin: timestamp
    └── isActive: boolean
```

### 2. مجموعة الطلاب (students)
```
students/
├── {studentId}/
    ├── userId: string (reference to users)
    ├── studentNumber: string
    ├── department: string
    ├── level: number (1, 2, 3, 4)
    ├── semester: number
    ├── personalInfo: {
    │   ├── fullName: string
    │   ├── dateOfBirth: timestamp
    │   ├── phone: string
    │   ├── address: string
    │   └── emergencyContact: string
    │   }
    ├── academicInfo: {
    │   ├── gpa: number
    │   ├── totalCredits: number
    │   ├── enrollmentDate: timestamp
    │   └── graduationDate: timestamp (optional)
    │   }
    └── isActive: boolean
```

### 3. مجموعة المعلمين (teachers)
```
teachers/
├── {teacherId}/
    ├── userId: string (reference to users)
    ├── employeeNumber: string
    ├── department: string
    ├── position: string (lecturer, assistant_professor, professor)
    ├── personalInfo: {
    │   ├── fullName: string
    │   ├── phone: string
    │   ├── office: string
    │   ├── bio: string
    │   └── specialization: string
    │   }
    ├── officeHours: array of {
    │   ├── day: string
    │   ├── startTime: string
    │   └── endTime: string
    │   }
    └── isActive: boolean
```

### 4. مجموعة الأقسام (departments)
```
departments/
├── {departmentId}/
    ├── name: string
    ├── description: string
    ├── head: string (reference to teachers)
    ├── requirements: {
    │   ├── minimumGrade: number
    │   ├── tuitionFee: number
    │   └── duration: number (years)
    │   }
    ├── courses: array of course references
    └── isActive: boolean
```

### 5. مجموعة المقررات (courses)
```
courses/
├── {courseId}/
    ├── code: string
    ├── name: string
    ├── description: string
    ├── credits: number
    ├── department: string (reference to departments)
    ├── level: number
    ├── semester: number
    ├── prerequisites: array of course references
    ├── instructor: string (reference to teachers)
    └── isActive: boolean
```

### 6. مجموعة التسجيلات (enrollments)
```
enrollments/
├── {enrollmentId}/
    ├── studentId: string (reference to students)
    ├── courseId: string (reference to courses)
    ├── semester: string
    ├── year: number
    ├── grade: number (optional)
    ├── status: string (enrolled, completed, dropped)
    ├── enrollmentDate: timestamp
    └── completionDate: timestamp (optional)
```

### 7. مجموعة الجداول الدراسية (schedules)
```
schedules/
├── {scheduleId}/
    ├── courseId: string (reference to courses)
    ├── teacherId: string (reference to teachers)
    ├── semester: string
    ├── year: number
    ├── sessions: array of {
    │   ├── day: string
    │   ├── startTime: string
    │   ├── endTime: string
    │   ├── room: string
    │   └── type: string (lecture, lab, tutorial)
    │   }
    └── isActive: boolean
```

### 8. مجموعة الاختبارات (exams)
```
exams/
├── {examId}/
    ├── courseId: string (reference to courses)
    ├── teacherId: string (reference to teachers)
    ├── title: string
    ├── type: string (midterm, final, quiz)
    ├── date: timestamp
    ├── duration: number (minutes)
    ├── room: string
    ├── instructions: string
    └── isActive: boolean
```

### 9. مجموعة المكتبة (library)
```
library/
├── {bookId}/
    ├── title: string
    ├── author: string
    ├── isbn: string
    ├── category: string (book, handout, summary, journal)
    ├── department: string
    ├── course: string (optional)
    ├── fileUrl: string
    ├── coverImage: string
    ├── description: string
    ├── uploadedBy: string (reference to teachers)
    ├── uploadDate: timestamp
    └── isActive: boolean
```

### 10. مجموعة الأخبار (news)
```
news/
├── {newsId}/
    ├── title: string
    ├── content: string
    ├── summary: string
    ├── image: string (URL)
    ├── author: string (reference to users)
    ├── publishDate: timestamp
    ├── category: string
    ├── isPublished: boolean
    └── views: number
```

### 11. مجموعة المتفوقين (topStudents)
```
topStudents/
├── {recordId}/
    ├── studentId: string (reference to students)
    ├── year: number
    ├── semester: string
    ├── gpa: number
    ├── rank: number
    ├── department: string
    ├── level: number
    └── isActive: boolean
```

### 12. مجموعة الإعدادات (settings)
```
settings/
├── general/
    ├── collegeName: string
    ├── collegeDescription: string
    ├── contactInfo: {
    │   ├── phone: string
    │   ├── email: string
    │   ├── address: string
    │   └── website: string
    │   }
    ├── socialMedia: {
    │   ├── facebook: string
    │   ├── twitter: string
    │   ├── instagram: string
    │   └── linkedin: string
    │   }
    └── logo: string (URL)
```

## قواعد الأمان (Security Rules)

### قواعد Firestore الأساسية:
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // المستخدمون يمكنهم قراءة وتعديل بياناتهم فقط
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // الطلاب يمكنهم قراءة بياناتهم فقط
    match /students/{studentId} {
      allow read: if request.auth != null && 
        (request.auth.uid == resource.data.userId || 
         get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin');
      allow write: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin';
    }
    
    // المعلمون يمكنهم قراءة وتعديل بياناتهم
    match /teachers/{teacherId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && 
        (request.auth.uid == resource.data.userId || 
         get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin');
    }
    
    // البيانات العامة قابلة للقراءة من قبل جميع المستخدمين المصادق عليهم
    match /departments/{document} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin';
    }
    
    match /courses/{document} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && 
        (get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role in ['admin', 'teacher']);
    }
    
    match /library/{document} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && 
        (get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role in ['admin', 'teacher']);
    }
    
    match /news/{document} {
      allow read: if true; // الأخبار متاحة للجميع
      allow write: if request.auth != null && 
        (get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role in ['admin', 'teacher']);
    }
  }
}
```

## فهارس قاعدة البيانات (Database Indexes)

### الفهارس المطلوبة:
1. **students**: `department`, `level`, `isActive`
2. **teachers**: `department`, `isActive`
3. **courses**: `department`, `level`, `semester`, `isActive`
4. **enrollments**: `studentId`, `courseId`, `semester`, `year`
5. **schedules**: `courseId`, `semester`, `year`, `isActive`
6. **exams**: `courseId`, `date`, `isActive`
7. **library**: `category`, `department`, `course`, `isActive`
8. **news**: `publishDate`, `category`, `isPublished`
9. **topStudents**: `year`, `semester`, `department`, `rank`

هذا التصميم يوفر هيكلاً مرناً وقابلاً للتوسع لنظام إدارة الكلية مع ضمان الأمان وسهولة الاستعلام.

